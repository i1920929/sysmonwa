

<?php $__env->startSection('content'); ?>
    <div class="container-header">
        <h1 class="text-2xl font-bold mb-4">Gestiónde clientes / Detalles</h1>
    </div>

    <div class="containercreate">
        <form>
            <div class="form-group">
                <label for="name">Nombre del Cliente:</label>
                <input type="text" id="name" name="name" class="form-control" value="<?php echo e($client->name); ?>" disabled>
            </div>
            <div class="form-group">
                <label for="location">Ubicación:</label>
                <input type="text" id="location" name="location" class="form-control" value="<?php echo e($client->location); ?>" disabled>
            </div>

            <div class="form-group">
                <label for="contact_info">Número de Contacto:</label>
                <input type="text" id="contact_info" name="contact_info" class="form-control" disabled  value="<?php echo e($client->contact_info); ?>">
            </div>

            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" class="form-control" value="<?php echo e($client->email); ?>" disabled>
            </div>


            <div class="buttons">
                <button type="button" class="volver">
                    <a href="<?php echo e(route('clients.index')); ?>">
                        <i class="fas fa-arrow-left mr-1"></i> Volver
                    </a>
                </button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sysmonwadev\resources\views/clients/show.blade.php ENDPATH**/ ?>