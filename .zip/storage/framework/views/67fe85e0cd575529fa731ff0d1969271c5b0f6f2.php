
<?php $__env->startSection('title', 'Gestión de Usuarios'); ?>

<?php $__env->startSection('content'); ?>

<div class="container-header">
    <h1 class="text-2xl font-bold mb-4">Gestión de Usuarios</h1>
</div>

<!-- Contenedor para el formulario de búsqueda y botón de agregar -->
<div class="border border-[#3E7FF5] p-4 rounded-lg mb-4 flex items-center space-x-2">
    <form action="<?php echo e(route('users.index')); ?>" method="GET" class="flex-grow">
        <input type="text" name="search" value="<?php echo e(request('search')); ?>" placeholder="Buscar por nombre o email"
               class="border border-gray-300 rounded-lg px-4 py-2 w-full" />
    </form>
    
    <a href="<?php echo e(route('users.create')); ?>" class="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600 flex items-center">
        <svg class="h-5 w-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4" />
        </svg>
        Agregar Usuario
    </a>
</div>

<!-- Tabla de Usuarios -->
<div class="overflow-x-auto bg-white rounded-lg shadow">
    <table class="min-w-full divide-y divide-gray-200">
        <thead class="bg-[#C4C4C4] table-header">
            <tr>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nombre</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Apellido</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Username</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Rol</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Acciones</th>
            </tr>
        </thead>
        <tbody class="bg-white divide-y divide-gray-200">
            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="px-6 py-4 whitespace-nowrap"><?php echo e($user->id); ?></td>
                    <td class="px-6 py-4 whitespace-nowrap"><?php echo e($user->first_name); ?></td>
                    <td class="px-6 py-4 whitespace-nowrap"><?php echo e($user->last_name); ?></td>
                    <td class="px-6 py-4 whitespace-nowrap"><?php echo e($user->username); ?></td>
                    <td class="px-6 py-4 whitespace-nowrap"><?php echo e($user->role); ?></td>
                    <td class="px-6 py-4 whitespace-nowrap flex space-x-2">
                        <!-- Ver -->
                        <a href="<?php echo e(route('users.show', $user)); ?>" class="bg-blue-500 text-white px-2 py-1 rounded hover:bg-blue-600 flex items-center">
                            <svg class="h-4 w-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3" />
                            </svg>
                            Ver
                        </a>

                        <!-- Editar -->
                        <a href="<?php echo e(route('users.edit', $user)); ?>" class="bg-yellow-500 text-white px-2 py-1 rounded hover:bg-yellow-600 flex items-center">
                            <svg class="h-4 w-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14.121 4.879l-9.192 9.192 1.415 1.415 9.192-9.192z" />
                            </svg>
                            Editar
                        </a>

                        <!-- Eliminar -->
                        <form id="deleteForm-<?php echo e($user->id); ?>" action="<?php echo e(route('users.destroy', $user)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="button" class="deleteBtn bg-red-500 hover:bg-red-700 text-white px-2 py-1 rounded flex items-center" data-form-id="deleteForm-<?php echo e($user->id); ?>">
                                <svg class="h-4 w-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                                </svg>
                                Eliminar
                            </button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7" class="text-center px-6 py-4">No hay usuarios disponibles.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <!-- Pop-up para Confirmar Eliminación -->
    <div id="deleteModal" style="display: none;">
        <div class="modal-content">
            <div class="container-header">
                <h2 class="text-2xl font-bold mb-4">Confirmación de Eliminación</h2>
            </div>
            <p>¿Estás seguro de eliminar el usuario seleccionado?</p>
            <button id="cancelBtn" class="btn btn-secondary">Cancelar</button>
            <button id="confirmDeleteBtn" class="btn btn-danger">Eliminar</button>
        </div>
    </div>
</div>

<!-- Enlaces de Paginación -->
<div class="mt-4">
    <?php echo e($users->links()); ?>

</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sysmonwadev\resources\views/users/index.blade.php ENDPATH**/ ?>