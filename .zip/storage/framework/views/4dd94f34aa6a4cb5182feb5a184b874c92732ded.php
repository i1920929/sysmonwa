
<?php $__env->startSection('title', 'Crear Sensor'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-header">
    <h1 class="text-2xl font-bold mb-4">Gestión de Sensores / Registro</h1>
</div>

<div class="containercreate">
    <form action="<?php echo e(route('sensors.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="name">Nombre del Sensor:</label>
            <input type="text" id="name" name="name" class="form-control" required>
        </div>

        <div class="form-group">
            <label for="type">Tipo de Sensor:</label>
            <select id="type" name="type" class="form-control" required>
                <option value="">Seleccione un tipo de sensor</option>
                <option value="consumo">Consumo</option>
                <option value="calidad">Calidad</option>
                <option value="nivel">Nivel</option>
            </select>
        </div>

        <div class="form-group">
            <label for="tank_id">Tanque Asociado:</label>
            <select id="tank_id" name="tank_id" class="form-control">
            <option value="">Seleccione un tanque</option>
                <?php $__currentLoopData = $tanks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($tank->id); ?>"><?php echo e($tank->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="buttons">
            <button type="button" class="volver"> <a href="<?php echo e(route('sensors.index')); ?>" >< Volver</a></button>
            <button type="submit" class="agregar"> + Agregar</button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sysmonwadev\resources\views/sensors/create.blade.php ENDPATH**/ ?>