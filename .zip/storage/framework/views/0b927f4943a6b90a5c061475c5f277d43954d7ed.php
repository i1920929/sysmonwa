

<?php $__env->startSection('content'); ?>
<div class="container-header">
    <h1 class="text-2xl font-bold mb-4">Gestión de Usuarios / Editar</h1>
</div>

<div class="containercreate">
    <form action="<?php echo e(route('users.update', $user->id)); ?>" method="POST" enctype="multipart/form-data"> <!-- Asegúrate de incluir enctype -->
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <!-- Nombre del Usuario -->
        <div class="form-group mb-3">
            <label for="first_name" class="form-label">Nombre:</label>
            <input type="text" id="first_name" name="first_name" class="form-control" value="<?php echo e($user->first_name); ?>" required>
        </div>

        <!-- Apellido del Usuario -->
        <div class="form-group mb-3">
            <label for="last_name" class="form-label">Apellido:</label>
            <input type="text" id="last_name" name="last_name" class="form-control" value="<?php echo e($user->last_name); ?>" required>
        </div>

        <!-- Nombre de Usuario -->
        <div class="form-group mb-3">
            <label for="username" class="form-label">Nombre de Usuario:</label>
            <input type="text" id="username" name="username" class="form-control" value="<?php echo e($user->username); ?>" required>
        </div>

        <!-- Email del Usuario -->
        <div class="form-group mb-3">
            <label for="email" class="form-label">Email:</label>
            <input type="email" id="email" name="email" class="form-control" value="<?php echo e($user->email); ?>" required>
        </div>

        <!-- Contraseña -->
        <div class="form-group mb-3">
            <label for="password" class="form-label">Contraseña (dejar en blanco para no cambiar):</label>
            <input type="password" id="password" name="password" class="form-control">
        </div>

        <!-- Confirmar Contraseña -->
        <div class="form-group mb-3">
            <label for="password_confirmation" class="form-label">Confirmar Contraseña:</label>
            <input type="password" id="password_confirmation" name="password_confirmation" class="form-control">
        </div>

        <!-- Imagen de Perfil Actual -->
        <div class="form-group mb-3">
            <label for="profile_image" class="form-label">Imagen de Perfil Actual:</label>
            <div>
                <img src="<?php echo e(asset('images/' . $user->profile_image)); ?>" alt="Imagen de perfil" width="150px">
            </div>
        </div>

        <!-- Cargar Nueva Imagen de Perfil -->
        <div class="form-group mb-3">
            <label for="profile_image" class="form-label">Cambiar Imagen de Perfil (opcional):</label>
            <input type="file" id="profile_image" name="profile_image" class="form-control <?php $__errorArgs = ['profile_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" accept="image/*">
            <?php $__errorArgs = ['profile_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <!-- Rol -->
        <?php if(Auth::user()->role === 'Administrador'): ?>
        <div class="form-group mb-3">
            <label for="role" class="form-label">Rol:</label>
            <select id="role" name="role" class="form-select" required>
                <option value="Usuario" <?php echo e($user->role == 'Usuario' ? 'selected' : ''); ?>>Usuario</option>
                <option value="Administrador" <?php echo e($user->role == 'Administrador' ? 'selected' : ''); ?>>Administrador</option>
            </select>
        </div>
        
        <!-- Lista de Clientes -->
        <div class="form-group mb-3">
            <label for="client_id" class="form-label">Seleccionar Cliente:</label>
            <select id="client_id" name="client_id" class="form-select">
                <option value="">Selecciona un cliente</option>
                <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($client->id); ?>" <?php echo e($user->client_id == $client->id ? 'selected' : ''); ?>><?php echo e($client->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <?php endif; ?>

        <!-- Botones para Guardar y Volver -->

        <?php if(Auth::user()->role === 'Administrador'): ?>


        <div class="buttons">
            <button type="button" class="volver"><a href="<?php echo e(route('users.index')); ?>">< Volver</a></button>
            <button type="submit" class="editar"> <i class="fas fa-edit mr-1"></i> Actualizar</button>
        </div>

        
        <?php else: ?>
            <div class="buttons">
            <button type="button" class="volver"><a href="/home">< Volver</a></button>
            <button type="submit" class="editar"> <i class="fas fa-edit mr-1"></i> Actualizar</button>
        </div>
        <?php endif; ?>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sysmonwadev\resources\views/users/edit.blade.php ENDPATH**/ ?>