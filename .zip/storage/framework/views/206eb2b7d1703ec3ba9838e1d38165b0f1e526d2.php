
<?php $__env->startSection('title', 'Editar Sensor'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-header">
    <h1 class="text-2xl font-bold mb-4">Gestión de Sensores / Editar</h1>
</div>

<div class="containercreate">
    <form action="<?php echo e(route('sensors.update', $sensor)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="form-group">
            <label for="name">Nombre del Sensor:</label>
            <input type="text" id="name" name="name" class="form-control" value="<?php echo e($sensor->name); ?>" required>
        </div>

        <div class="form-group">
            <label for="type">Tipo de Sensor:</label>
            <select id="type" name="type" class="form-control" required>
                <option value="consumo" <?php echo e($sensor->type == 'consumo' ? 'selected' : ''); ?>>Consumo</option>
                <option value="calidad" <?php echo e($sensor->type == 'calidad' ? 'selected' : ''); ?>>Calidad</option>
                <option value="nivel" <?php echo e($sensor->type == 'nivel' ? 'selected' : ''); ?>>Nivel</option>
            </select>
        </div>

        <div class="form-group">
            <label for="tank_id">Tanque Asociado:</label>
            <select id="tank_id" name="tank_id" class="form-control">
                <?php $__currentLoopData = $tanks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($tank->id); ?>" <?php echo e($sensor->tank_id == $tank->id ? 'selected' : ''); ?>><?php echo e($tank->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="buttons">
                <button type="button" class="volver">
                    <a href="<?php echo e(route('sensors.index')); ?>">
                        <i class="fas fa-arrow-left mr-1"></i> Volver
                    </a>
                </button>
                <button type="submit" class="agregar">
                    <i class="fas fa-edit mr-1"></i> Actualizar
                </button>
            </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sysmonwadev\resources\views/sensors/edit.blade.php ENDPATH**/ ?>