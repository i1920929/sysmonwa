<!-- resources/views/partials/menu.blade.php -->

    <div class="containers">
        <div class="sidebar">
            <div class="sidebaruno">
                <div class="logo">
                    <div class="logo-img">
                        <img src="../../img/logo.png" alt="">
                    </div>
                </div>

                <div class="logo">
                    <div class="user-img">
                    <?php if(Auth::check() && Auth::user()->profile_image): ?>
                        <img src="<?php echo e(asset('images/' . Auth::user()->profile_image)); ?>" alt="Imagen de perfil">
                    <?php else: ?>
                        <img src="../../img/user.png" alt="Imagen de perfil por defecto">
                    <?php endif; ?>
                    </div>
                </div>

                <div class="head">
                    <div class="user-details">
                        <p class="name"><?php echo e(Auth::user()->username); ?></p>
                        <p class="role"><?php echo e(Auth::user()->role); ?></p>
                    </div>
                </div>
                <a href="<?php echo e(route('users.edit', Auth::id())); ?>">
                    <i class="icon"></i>
                    <span class="text">Editar Perfil</span>
                </a>

            </div>
            <div class="nav">
                <div class="menu">
                    <p class="title">Menú</p>
                    <ul>
                    <?php if(auth()->guard()->check()): ?>
                            <?php if(Auth::user()->role !== 'Usuario'): ?>
                                <li class="active">
                                    <a href="#">
                                        <img src="../../img/icon-admin.png" alt="">
                                        <span class="text">Administración</span>
                                        <i class="arrow ph-bold ph-caret-down"></i>
                                    </a>
                                    <ul class="sub-menu">
                                        <li>
                                            <a href="<?php echo e(route('users.index')); ?>">
                                                <span class="text">Usuarios</span>
                                            </a>
                                            <a href="<?php echo e(route('clients.index')); ?>">
                                                <span class="text">Clientes</span>
                                            </a>
                                            <a href="<?php echo e(route('tanques.index')); ?>">
                                                <span class="text">Tanques</span>
                                            </a>
                                            <a href="<?php echo e(route('sensors.index')); ?>">
                                                <span class="text">Sensores</span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                            <?php endif; ?>
                        <?php endif; ?>
                        <li>
                            <a href="#">
                                <img src="../../img/icon-consumo.png" alt="">
                                <span class="text">Consumo</span>
                                <i class="arrow ph-bold ph-caret-down"></i>
                            </a>
                            <ul class="sub-menu">
                                <li>
                                    <a href="/consumption/realtime">
                                        <span class="text">En tiempo real</span>
                                    </a>
                                    <a href="/consumption/historical">
                                        <span class="text">Histórico</span>
                                    </a>
                                    <a href="#">
                                        <span class="text">Predicción</span>
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <a href="#">
                            <img src="../../img/icon-nivel.png" alt="">
                                <span class="text">Nivel</span>
                                <i class="arrow ph-bold ph-caret-down"></i>
                            </a>
                            <ul class="sub-menu">
                                <li>
                                    <a href="#">
                                        <span class="text">En tiempo real</span>
                                    </a>
                                    <a href="#">
                                        <span class="text">Histórico</span>
                                    </a>
                                    <a href="#">
                                        <span class="text">Predicción</span>
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <a href="#">
                                <img src="../../img/icon-calidad.png" alt="">
                                <span class="text">Calidad</span>
                                <i class="arrow ph-bold ph-caret-down"></i>
                            </a>
                            <ul class="sub-menu">
                                <li>
                                    <a href="#">
                                        <span class="text">En tiempo real</span>
                                    </a>
                                    <a href="#">
                                        <span class="text">Histórico</span>
                                    </a>
                                    <a href="#">
                                        <span class="text">Predicción</span>
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <a href="#">
                                <img src="../../img/icon-home.png" alt="">
                                <span class="text">Inicio</span>
                            </a>
                        </li>
                        <li>

                            <a  href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                                      <img src="../../img/icon-salir.png" alt="">
                                        <?php echo e(__('Cerrar sesión')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>

                        </li>
                    </ul>


                </div>
            </div>
        </div>
    </div>
<?php /**PATH C:\xampp\htdocs\sysmonwadev\resources\views/partials/menu.blade.php ENDPATH**/ ?>