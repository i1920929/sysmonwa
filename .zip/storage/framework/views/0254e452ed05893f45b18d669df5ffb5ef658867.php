

<?php $__env->startSection('content'); ?>
<div class="container-header">
    <h1 class="text-2xl font-bold mb-4">Gestión de Usuarios / Detalles</h1>
</div>

<div class="containercreate">
    <form>
        <div class="form-group">
            <label for="first_name">Nombre:</label>
            <input type="text" id="first_name" name="first_name" class="form-control" value="<?php echo e($user->first_name); ?>" disabled>
        </div>

        <div class="form-group">
            <label for="last_name">Apellido:</label>
            <input type="text" id="last_name" name="last_name" class="form-control" value="<?php echo e($user->last_name); ?>" disabled>
        </div>

        <div class="form-group">
            <label for="username">Nombre de Usuario:</label>
            <input type="text" id="username" name="username" class="form-control" value="<?php echo e($user->username); ?>" disabled>
        </div>

        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" class="form-control" value="<?php echo e($user->email); ?>" disabled>
        </div>

        <div class="form-group">
            <label for="role">Rol:</label>
            <input type="text" id="role" name="role" class="form-control" value="<?php echo e($user->role); ?>" disabled>
        </div>

        <div class="form-group">
            <label for="client_id">Cliente:</label>
            <input type="text" id="client_id" name="client_id" class="form-control" value="<?php echo e($user->client ? $user->client->name : 'Sin Cliente'); ?>" disabled>
        </div>

        <div class="buttons">
            <button type="button" class="volver">
                <a href="<?php echo e(route('users.index')); ?>">
                    <i class="fas fa-arrow-left mr-1"></i> Volver
                </a>
            </button>
        
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sysmonwadev\resources\views/users/show.blade.php ENDPATH**/ ?>