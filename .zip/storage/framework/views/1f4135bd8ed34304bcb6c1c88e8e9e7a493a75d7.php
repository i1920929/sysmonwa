
<?php $__env->startSection('title', 'Inicio'); ?>

<?php $__env->startSection('content'); ?>

<div class="container-header">
    <h1 class="text-2xl font-bold mb-4">Gestión de tanques / Registro </h1>
</div>  

<div class="containercreate">
    <form action="<?php echo e(route('tanques.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="name">Nombre del tanque:</label>
            <input type="text" id="name" name="name" class="form-control" required>
        </div>

        <div class="form-group">
            <label for="location">Ubicación:</label>
            <input type="text" id="location" name="location" class="form-control" required>
        </div>

        <div class="form-group">
            <label for="capacity">Capacidad:</label>
            <input type="number" id="capacity" name="capacity" class="form-control" required>
        </div>

        <div class="form-group">
            <label for="unit">Unidad:</label>
            <input type="text" id="unit" name="unit" value="litros"  class="form-control" required>
        </div>

        <div class="form-group">
            <label for="client_id">Cliente:</label>
            <select id="client_id" name="client_id" class="form-control" required>
                <option value="">Seleccione un cliente</option>
                <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($client->id); ?>"><?php echo e($client->name); ?></option> <!-- Asegúrate de que el campo name exista en el modelo Client -->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="buttons">
            <button type="button" class="volver"> <a href="<?php echo e(route('tanques.index')); ?>" >< Volver</a></button>
            <button type="submit" class="agregar"> + Agregar</button>
        </div>
    </form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sysmonwadev\resources\views/tanques/create.blade.php ENDPATH**/ ?>